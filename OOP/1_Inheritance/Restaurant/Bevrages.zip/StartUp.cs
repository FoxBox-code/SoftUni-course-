﻿using Restaurant.Foods;

namespace Restaurant
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Fish salmoon = new Fish("salmoon", 30);
            Cake lindCake = new Cake("LindCake");
            Soup creamSoup = new Soup("CreamSoup", 10, 300);




        }
    }
}
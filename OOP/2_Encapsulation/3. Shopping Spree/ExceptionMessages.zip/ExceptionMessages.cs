﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3._Shopping_Spree
{
    public class ExceptionMessages
    {
        public const string NameExceptionMessage = "Name cannot be empty";
        public const string MoneyExeptionMessage = "Money cannot be negative";
    }
}

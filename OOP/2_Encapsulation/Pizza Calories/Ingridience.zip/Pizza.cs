﻿using Pizza_Calories.Ingridience;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pizza_Calories
{
    public class Pizza
    {
        private string name;
        private Dough dough;

       




        private List<Topping> toppings;

        public Pizza(string name, Dough dough) 
        {
            Name = name;
            Dough = dough;
            


            toppings = new List<Topping>();

        }
        public Dough Dough
        {
            get { return dough; }
            set { dough = value; }
        }
        public string Name
        {
            get { return name; }
            set { 
                if(string.IsNullOrWhiteSpace(value) || value.Length > 15)
                {
                    throw new ArgumentException("Pizza name should be between 1 and 15 symbols.");
                }
                name = value; }
        }

        public void AddTopping(Topping topping)
        {
            if (toppings.Count > 10)
            {
                throw new ArgumentException("Number of toppings should be in range [0..10].");
            }
            toppings.Add(topping);
        }
        

        public override string ToString()
        {
            double totalCal = 0;
            foreach (Topping topping in toppings)
            {
                totalCal += topping.Calories();
            }
            var cal= dough.Calories();
            totalCal += cal;

            return $"{Name} - {totalCal:f2} Calories.".ToString();
        }


    }
}

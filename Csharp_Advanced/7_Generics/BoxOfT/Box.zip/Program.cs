﻿namespace BoxOfT
{
    class StartUp
    {
        static void Main()
        {
            Console.WriteLine(5);
        }
    }
}
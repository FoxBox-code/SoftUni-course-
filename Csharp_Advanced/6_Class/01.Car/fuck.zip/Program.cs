﻿namespace CarManufacturer

{

    class Car

    {

        // TODO: define the Car class members here …

    }

}